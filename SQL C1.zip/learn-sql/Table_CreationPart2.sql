CREATE TABLE examples(
     id INT AUTO_INCREMENT PRIMARY KEY,
     col1 INT, -- Integer
     col2 TINYINT, -- Integer
     col3 SMALLINT, -- Integer
     col4 MEDIUMINT, -- Integer
     col5 BIGINT, -- Integer
     col6 DECIMAL(15,5), -- Double
     col7 FLOAT,  -- Double
     col8 DOUBLE,  -- Double
     col9 CHAR(40), -- String
     col10 VARCHAR(100), -- String
     col11 TEXT, -- Long String
     col12 TINYTEXT,-- TINY String
     col13 MEDIUMTEXT,-- MEDIUM String
     col14 LONGTEXT, -- LONG String
     col15 DATE, -- Date
     col16 DATETIME, -- Date
     col17 TIMESTAMP, -- Date
     col18 TIME, -- Date
     col19 YEAR, -- Date
     col20 ENUM('processing','completed','success','failed'), -- String
     col21 BLOB -- Binary
);