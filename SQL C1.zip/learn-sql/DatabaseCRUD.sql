INSERT INTO 
employees(`name`,`designation`,`salary`) 
VALUES 
("Rabbil Hasan","Software Engineer",15000),
("Arifur Rahman","Senior Software Engineer",25000),
("Sadia Sultana","Project Manager",35000),
("Tanvir Ahmed","Intern",8000),
("Nusrat Jahan","HR Manager",30000);


SELECT * FROM employees;
SELECT `name`,`designation` FROM employees;

DELETE FROM employees WHERE id=2;

UPDATE employees 
SET 
salary=18000,
designation="Senior Software Engineer" 
WHERE id=1;

