SET @num1=10;
SET @num2=20;
SELECT 
    @num1 + @num2 AS Addition,
    @num1 - @num2 AS Subtraction,
    @num1 * @num2 AS Multiplication,
    @num1 / @num2 AS Division,
    @num1 % @num2 AS Modulus,
    POWER(@num1, 2) AS Power,
    SQRT(@num1) AS SquareRoot,
    ROUND(@num1 / @num2, 2) AS RoundedValue,
    ABS(@num1 - @num2) AS AbsoluteValue,
    LOG10(@num1) AS LogBase10,
    GREATEST(@num1, @num2) AS GreatestValue,
    LEAST(@num1, @num2) AS LeastValue;

